$(function() {
	setInterval(function() {
		$("div.slaider__slaid").find("div.slider__conteiner").animate({"left": "-=672px"}, 1000);
	}, 3000);
});

